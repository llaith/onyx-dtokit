/*
 * Created on Aug 31, 2007
 *
 */
package tkt.form.model;

public class FormModelField<T> {

}
