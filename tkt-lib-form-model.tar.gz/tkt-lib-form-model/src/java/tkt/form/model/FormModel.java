/*
 * Created on Aug 31, 2007
 *
 */
package tkt.form.model;

public interface FormModel {

}
