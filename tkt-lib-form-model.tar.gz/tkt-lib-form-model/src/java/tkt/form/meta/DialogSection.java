/*
 * Created on 11/03/2007
 *
 */
package tkt.form.meta;



public class DialogSection extends AbstractFormSection {

    private final String heading;
    private final String description; 
    
    public DialogSection(int position, String heading, String description) {
        super(position);
        this.heading = heading;
        this.description = description;
    }
    
    public String getHeading() {
        return this.heading;
    }
    
    public String getDescription() {
        return this.description;
    }

    /* 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((this.description == null) ? 0 : this.description.hashCode());
        result = prime * result + ((this.heading == null) ? 0 : this.heading.hashCode());
        return result;
    }

    /* 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final DialogSection other = (DialogSection) obj;
        if (this.description == null) {
            if (other.description != null)
                return false;
        } else if (!this.description.equals(other.description))
            return false;
        if (this.heading == null) {
            if (other.heading != null)
                return false;
        } else if (!this.heading.equals(other.heading))
            return false;
        return true;
    }

}
