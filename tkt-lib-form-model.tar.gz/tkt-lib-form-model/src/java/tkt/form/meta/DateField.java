/*
 * Created on 12/03/2007
 *
 */
package tkt.form.meta;


public class DateField extends FieldMeta {

    public DateField(String ident) {
        super(ident);
    }
    
}
