/*
 * Created on 31/05/2006
 *
 */
package tkt.form.meta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



/**
 * @author nosd
 * 
 * Internationalization is outside form+field in the builder. This is the model that may be going as a string to a dumb client like html pages in JSON format etc.
 * 
 */
public class FormMeta {

    private final String title; 
    private final Map<String,String> properties = new HashMap<String,String>(); // read-only displayed at top of form
    private List<AbstractFormSection> sections = new ArrayList<AbstractFormSection>();

    public FormMeta(String title) {
        super();
        this.title = title;
    }
    
    public FormMeta(String title, final Map<String,String> properties) {
        super();
        this.title = title;
        this.properties.putAll(properties);
    }
    
    public String getTitle() {
        return this.title;
    }
    
    public void addFormSection(AbstractFormSection section) {
        this.sections.add(section);
    }
    
    public List<AbstractFormSection> getFormSections() {
        return this.sections;
    }

    /* 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((this.properties == null) ? 0 : this.properties.hashCode());
        result = prime * result + ((this.sections == null) ? 0 : this.sections.hashCode());
        result = prime * result + ((this.title == null) ? 0 : this.title.hashCode());
        return result;
    }

    /* 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final FormMeta other = (FormMeta) obj;
        if (this.properties == null) {
            if (other.properties != null)
                return false;
        } else if (!this.properties.equals(other.properties))
            return false;
        if (this.sections == null) {
            if (other.sections != null)
                return false;
        } else if (!this.sections.equals(other.sections))
            return false;
        if (this.title == null) {
            if (other.title != null)
                return false;
        } else if (!this.title.equals(other.title))
            return false;
        return true;
    }

}
