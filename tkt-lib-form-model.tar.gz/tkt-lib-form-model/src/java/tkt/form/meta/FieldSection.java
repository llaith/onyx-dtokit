/*
 * Created on 31/05/2006
 *
 */
package tkt.form.meta;

import java.util.ArrayList;
import java.util.List;



/**
 * 
 * @author nosd
 *
 */
public class FieldSection extends AbstractFormSection { // the T is the children type

    private final List<FieldGroup> groups = new ArrayList<FieldGroup>();
    private final String title;
    private final String helpText; // is also wizard mode text
    
    /**
     * 
     * @param ident
     */
    public FieldSection(final int position, final String title, final String helpText) {
        super(position);
        this.title = title;
        this.helpText = helpText;
    }

    public void addField(FieldMeta  fieldMeta) {
        this.addFieldGroup(new FieldGroup(fieldMeta));
    }
    
    public void addFieldGroup(FieldGroup group) {
        this.groups.add(group);
    }

    /**
     * @return the groups
     */
    public List<FieldGroup> getGroups() {
        return this.groups;
    }
    
    /**
     * @return the title
     */
    public String getTitle() {
        return this.title;
    }

    /**
     * @return the helpText
     */
    public String getHelpText() {
        return this.helpText;
    }

    /* 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((this.groups == null) ? 0 : this.groups.hashCode());
        result = prime * result + ((this.helpText == null) ? 0 : this.helpText.hashCode());
        result = prime * result + ((this.title == null) ? 0 : this.title.hashCode());
        return result;
    }

    /* 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final FieldSection other = (FieldSection) obj;
        if (this.groups == null) {
            if (other.groups != null)
                return false;
        } else if (!this.groups.equals(other.groups))
            return false;
        if (this.helpText == null) {
            if (other.helpText != null)
                return false;
        } else if (!this.helpText.equals(other.helpText))
            return false;
        if (this.title == null) {
            if (other.title != null)
                return false;
        } else if (!this.title.equals(other.title))
            return false;
        return true;
    }

}