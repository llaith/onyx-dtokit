/*
 * Created on 12/03/2007
 *
 */
package tkt.form.meta;



public class CheckboxField extends FieldMeta {

    public CheckboxField(String ident) {
        super(ident);
    }
    

}
