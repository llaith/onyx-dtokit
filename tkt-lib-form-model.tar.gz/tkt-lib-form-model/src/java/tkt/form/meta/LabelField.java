/*
 * Created on 12/03/2007
 *
 */
package tkt.form.meta;


/**
 * 
 * @author nos
 * 
 * This class is used for labels mixed in the display - not for read only labels. That would be best done with a readonOnly text field.
 *
 */
public class LabelField extends FieldMeta {

    private String text;
    
    public LabelField(String ident, String text) {
        super(ident);
        this.text = text;
    }
    
    /**
     * @return the text
     */
    public String getText() {
        return this.text;
    }

    /**
     * @param text the text to set
     */
    public void setText(String text) {
        this.text = text;
    }

    /* 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((this.text == null) ? 0 : this.text.hashCode());
        return result;
    }

    /* 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        final LabelField other = (LabelField) obj;
        if (this.text == null) {
            if (other.text != null)
                return false;
        } else if (!this.text.equals(other.text))
            return false;
        return true;
    }
    
}