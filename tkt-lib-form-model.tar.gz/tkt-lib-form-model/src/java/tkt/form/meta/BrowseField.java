/*
 * Created on 12/03/2007
 *
 */
package tkt.form.meta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tkt.foundation.ref.RefType;

/**
 * 
 * @author nos
 * 
 * Design Notes:
 * 
 * VERY VERY IMPORTANT : Chooser allows for concept of Object Browse (like RMT) it is NOT a 'search' 
 *
 */
public class BrowseField extends FieldMeta {

    private List<RefType> refTypes = new ArrayList<RefType>();
    private boolean allowMany = false;
    
    public BrowseField(final String ident, boolean allowMany, RefType[] refTypes) {
        this(ident,allowMany,Arrays.asList(refTypes));
    }
    
    public BrowseField(final String ident, boolean allowMany, List<RefType> refTypes) {
        super(ident);
        this.allowMany = allowMany;
        this.refTypes.addAll(refTypes);
    }
    
    public boolean isAllowMany() {
        return this.allowMany;
    }
    
    /**
     * @return the refTypes
     */
    public List<RefType> getRefTypes() {
        return this.refTypes;
    }

    /**
     * @param refTypes the refTypes to set
     */
    public void setRefTypes(List<RefType> refTypes) {
        this.refTypes = refTypes;
    }

    /**
     * @param allowMany the allowMany to set
     */
    public void setAllowMany(boolean allowMany) {
        this.allowMany = allowMany;
    }

    /* 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (this.allowMany ? 1231 : 1237);
        result = prime * result + ((this.refTypes == null) ? 0 : this.refTypes.hashCode());
        return result;
    }

    /* 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final BrowseField other = (BrowseField) obj;
        if (this.allowMany != other.allowMany)
            return false;
        if (this.refTypes == null) {
            if (other.refTypes != null)
                return false;
        } else if (!this.refTypes.equals(other.refTypes))
            return false;
        return true;
    }

}
