/*
 * Created on 12/03/2007
 *
 */
package tkt.form.meta;


/**
 * 
 * @author nos
 * 
 * Now takes a hashmap name=value string.
 *
 */
public class SummaryField extends FieldMeta {

    public SummaryField(final String ident) {
        super(ident);
    }

}
