/*
 * Created on 11/03/2007
 *
 */
package tkt.form.meta;



public abstract class AbstractFormSection {

    private final int position; 
    
    public AbstractFormSection(int position) {
        super();
        this.position = position;
    }

    /**
     * @return the position
     */
    public int getPosition() {
        return this.position;
    }

    /* 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + this.position;
        return result;
    }

    /* 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final AbstractFormSection other = (AbstractFormSection) obj;
        if (this.position != other.position)
            return false;
        return true;
    }
    
}
