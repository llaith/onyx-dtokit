/*
 * Created on 31/05/2006
 *
 */
package tkt.form.meta;







/**
 * 
 * @author nosd
 * 
 * TODO:
 * Make sure there are no 'up' references (foreign key refs) in objects in this heirarchy. Persistent object need them (neccessary evil) but FormModels do not!
 * 
 * Sera Software
 * 
 * No longer uses depencies as it is (a) a flat structure and (b) assures processing in top-down order
 *
 * Supports disconnected mode where model is not attached. Also supports read only mode where one way communication is supported
 *
 * In the case of hard coded labels we set an initial peekValue, and put only a viewWriteAdapter in which should cause the same value
 * to be pushed back to the screen each time - effectively making it a constant!. Cool!
 *
 *
 *For better integration this really needs to have a label before and label after and 'newline' attributes added... the group cannot server this purpose
 *
 */
public abstract class FieldMeta {

    private final String ident; // for the model adapter at least. Basically can be thought of as the param!

    private boolean required = false;
    private boolean readOnly = false; // if this is true then we do not use a ViewReadAdapter
    
    /**
     *  
     */
    public FieldMeta(final String ident) {
        super();
        this.ident = ident;
    }

    /**
     * @return the ident
     */
    public String getIdent() {
        return this.ident;
    }

    /**
     * @return the group
     *
    public FieldGroup getGroup() {
        return this.group;
    }

    /**
     * @return the required
     */
    public boolean isRequired() {
        return this.required;
    }

    /**
     * @return the readOnly
     */
    public boolean isReadOnly() {
        return this.readOnly;
    }

    /**
     * @return the connectModel
     *
    public boolean isConnectModel() {
        return this.connectModel;
    }

    /**
     * @return the dependentField
     *
    public Field<?> getDependentField() {
        return this.dependentField;
    }

    /**
     * Must be usable with a toString
     * 
     * @return the dependentValue
     *
    public Object getDependentValue() {
        return this.dependentValue;
    }

    /**
     * @param group the group to set
     *
    public void setGroup(FieldGroup group) {
        this.group = group;
    }

    /**
     * @param required the required to set
     */
    public void setRequired(boolean required) {
        this.required = required;
    }

    /**
     * @param readOnly the readOnly to set
     */
    public void setReadOnly(boolean readOnly) {
        this.readOnly = readOnly;
    }

    /* 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((this.ident == null) ? 0 : this.ident.hashCode());
        result = prime * result + (this.readOnly ? 1231 : 1237);
        result = prime * result + (this.required ? 1231 : 1237);
        return result;
    }

    /* 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final FieldMeta other = (FieldMeta) obj;
        if (this.ident == null) {
            if (other.ident != null)
                return false;
        } else if (!this.ident.equals(other.ident))
            return false;
        if (this.readOnly != other.readOnly)
            return false;
        if (this.required != other.required)
            return false;
        return true;
    }

    /*
    public <S> void setEnabledDependency(Field<S> field, S enabledValue) {
        // guarantees if have one then have both also helps the isEnabled check
        if (field == null) throw new IllegalArgumentException("The param [field] cannot be null in Field.setEnabledDependency");
        if (enabledValue== null) throw new IllegalArgumentException("The param [enabledValue] cannot be null in Field.setEnabledDependency");
        this.dependentField = field;
        this.dependentValue = enabledValue;
        //field.addDependentField(this); -- not really needed because we guarantee top to bottom execution
    }
    */
    
}