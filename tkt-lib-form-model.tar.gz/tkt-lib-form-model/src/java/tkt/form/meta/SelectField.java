/*
 * Created on 12/03/2007
 *
 */
package tkt.form.meta;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;



public class SelectField extends FieldMeta {

    private final List<String> choices;
    
    public SelectField(final String ident, final String[] choices) {
        super(ident);
        this.choices = Arrays.asList(choices);
    }
    
    public Collection<String> getChoices() {
        return this.choices;
    }

    /* 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((this.choices == null) ? 0 : this.choices.hashCode());
        return result;
    }

    /* 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        final SelectField other = (SelectField) obj;
        if (this.choices == null) {
            if (other.choices != null)
                return false;
        } else if (!this.choices.equals(other.choices))
            return false;
        return true;
    }


}
