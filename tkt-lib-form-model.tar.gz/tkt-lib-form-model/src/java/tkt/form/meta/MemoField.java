/*
 * Created on 12/03/2007
 *
 */
package tkt.form.meta;



/**
 * Could create a spinner type for eg from this - or a mask edited type
 * @author nos
 *
 */
public class MemoField extends FieldMeta {

    public MemoField(String ident) {
        super(ident);
    }
    

}
