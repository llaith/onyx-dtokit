/*
 * Created on 13/03/2007
 *
 */
package tkt.form.meta;

import java.util.ArrayList;
import java.util.List;


public class FieldGroup {

    private final List<FieldMeta> fieldMetas = new ArrayList<FieldMeta>();
    private FieldMeta dependentField = null;
    private Object dependentValue = null;
    
    public FieldGroup() {
        super();
    }
    
    public FieldGroup(FieldMeta fieldMeta) {
        super();
        this.addFormField(fieldMeta);
    }
    
    public void addFormField(FieldMeta fieldMeta) {
        this.fieldMetas.add(fieldMeta);
        //field.setGroup(this);
    }
    
    public int getFieldCount() {
        return this.fieldMetas.size();
    }

    /**
     * @return the fields
     */
    public List<FieldMeta> getFields() {
        return this.fieldMetas;
    }
    
    /**
     * @return the dependentField
     */
    public FieldMeta getDependentField() {
        return this.dependentField;
    }

    /**
     * Must be usable with a toString
     * 
     * @return the dependentValue
     */
    public Object getDependentValue() {
        return this.dependentValue;
    }

    public void setDependency(CheckboxField field, boolean enabledValue) {
        // guarantees if have one then have both also helps the isEnabled check
        if (field == null) throw new IllegalArgumentException("The param [field] cannot be null in Field.setEnabledDependency");
        this.dependentField = field;
        this.dependentValue = Boolean.valueOf(enabledValue);
        //field.addDependentField(this); -- not really needed because we guarantee top to bottom execution
    }

    public void setDependency(SelectField field, String enabledValue) {
        if (field == null) throw new IllegalArgumentException("The param [field] cannot be null in Field.setEnabledDependency");
        this.dependentField = field;
        this.dependentValue = enabledValue;
    }

    /* 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((this.dependentField == null) ? 0 : this.dependentField.hashCode());
        result = prime * result + ((this.dependentValue == null) ? 0 : this.dependentValue.hashCode());
        result = prime * result + ((this.fieldMetas == null) ? 0 : this.fieldMetas.hashCode());
        return result;
    }

    /* 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final FieldGroup other = (FieldGroup) obj;
        if (this.dependentField == null) {
            if (other.dependentField != null)
                return false;
        } else if (!this.dependentField.equals(other.dependentField))
            return false;
        if (this.dependentValue == null) {
            if (other.dependentValue != null)
                return false;
        } else if (!this.dependentValue.equals(other.dependentValue))
            return false;
        if (this.fieldMetas == null) {
            if (other.fieldMetas != null)
                return false;
        } else if (!this.fieldMetas.equals(other.fieldMetas))
            return false;
        return true;
    }
    
}
