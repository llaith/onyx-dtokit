/*
 * Created on Aug 23, 2007
 *
 */
package tkt.foundation.date;

import java.util.Date;

public interface IDate {

    public Date getDate();
    
}
