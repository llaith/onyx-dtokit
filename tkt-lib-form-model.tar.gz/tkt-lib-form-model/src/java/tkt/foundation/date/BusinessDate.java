/*
 * Created on Aug 23, 2007
 *
 */
package tkt.foundation.date;

import java.util.Date;

public class BusinessDate implements IDate {

    public static BusinessDate Today() {
        return new BusinessDate(new Date());
    }
    
    private java.util.Date date = null;
    
    public BusinessDate(java.util.Date date) {
        this.date = date;
        // todo: strip time portion
    }
    
    public java.util.Date getDate() {
        return this.date;
    }

    /* 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((this.date == null) ? 0 : this.date.hashCode());
        return result;
    }

    /* 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final BusinessDate other = (BusinessDate) obj;
        if (this.date == null) {
            if (other.date != null)
                return false;
        } else if (!this.date.equals(other.date))
            return false;
        return true;
    }
    
}
