/*
 * Created on Aug 23, 2007
 *
 */
package tkt.foundation.form.handler;

/**
 * 
 * @author nos
 * 
 * Design:
 * 
 * Loads a form inside and does the following:
 * 1) Handles navigation between wizard panes
 * 2)  Navigation to links/detail elements
 * 3) Invokes object browser
 * 4) Set & Get handlers for fields / ConnectedModel adapters & String adapters
 * 
 * eg:
 * FormHandler = new EchoWizardFormHandler(FormManager.getForm("person-view"));
 *
 */
public class FormHandler {

    
    
    
}
