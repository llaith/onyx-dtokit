/*
 * Created on Aug 23, 2007
 *
 */
package tkt.foundation.form.meta.builder.crud;

/**
 * 
 * @author nos
 *
 * 1) Support Annotations, EJB3 + own as overrides
 * 2) Can build forms or sections etc so:
 *      FieldSection fs = crudFormBuilder.buildFormSection(Person.class);
 *      Form f = crudFormBuilder.buildForm(Person.class);
 *      
 *      
 *
 */
public class CrudFormBuilder {

}
