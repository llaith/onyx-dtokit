/*
 * Created on Apr 24, 2007
 *
 */
package tkt.foundation.form.meta.builder.xml;

/*
 * This wont work as a generic class
 */
public interface XmlConversionHandler {

    public Class<?> getClassHandled();
    public Object fromString(String s);
    public String toString(Object o);
    
}
