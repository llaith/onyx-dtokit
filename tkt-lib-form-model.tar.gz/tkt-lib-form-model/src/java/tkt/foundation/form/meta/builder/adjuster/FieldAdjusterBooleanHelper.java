/*
 * Created on Aug 23, 2007
 *
 */
package tkt.foundation.form.meta.builder.adjuster;


public class FieldAdjusterBooleanHelper extends AbstractFieldAdjusterHelper {

    public FieldAdjusterBooleanHelper(FieldAdjuster adjuster) {
        super(adjuster);
    }

    public FieldAdjusterBooleanHelper setLabels(String trueLabel, String falseLabel) {
        this.adjuster.setLabels(trueLabel,falseLabel);
        return this;
    }

}
