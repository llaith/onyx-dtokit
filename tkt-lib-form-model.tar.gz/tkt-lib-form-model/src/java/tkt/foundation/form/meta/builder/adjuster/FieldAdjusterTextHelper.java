/*
 * Created on Aug 23, 2007
 *
 */
package tkt.foundation.form.meta.builder.adjuster;


public class FieldAdjusterTextHelper extends AbstractFieldAdjusterHelper {

    public FieldAdjusterTextHelper(FieldAdjuster adjuster) {
        super(adjuster);
    }

    public FieldAdjusterTextHelper setMask(String mask) {
        this.adjuster.setMask(mask);
        return this;
    }

    public FieldAdjusterTextHelper setMaxLength(int max) {
        this.adjuster.setMaxLength(max);
        return this;
    }
    
    public FieldAdjusterTextHelper setMinLength(int min) {
        this.adjuster.setMinLength(min);
        return this;
    }
    
}
