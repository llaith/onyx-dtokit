/*
 * Created on Aug 23, 2007
 *
 */
package tkt.foundation.form.meta.builder.adjuster;

import java.math.BigInteger;


public class FieldAdjusterIntegerHelper extends AbstractFieldAdjusterHelper {

    public FieldAdjusterIntegerHelper(FieldAdjuster adjuster) {
        super(adjuster);
    }

    public FieldAdjusterIntegerHelper setMaximum(BigInteger max) {
        this.adjuster.setMaximum(max);
        return this;
    }

    public FieldAdjusterIntegerHelper setMinimum(BigInteger min) {
        this.adjuster.setMinimum(min);
        return this;
    }
    
}
