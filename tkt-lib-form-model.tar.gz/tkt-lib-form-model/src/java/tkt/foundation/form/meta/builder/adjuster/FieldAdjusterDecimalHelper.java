/*
 * Created on Aug 23, 2007
 *
 */
package tkt.foundation.form.meta.builder.adjuster;

import java.math.BigDecimal;


public class FieldAdjusterDecimalHelper extends AbstractFieldAdjusterHelper {

    public FieldAdjusterDecimalHelper(FieldAdjuster adjuster) {
        super(adjuster);
    }

    public FieldAdjusterDecimalHelper setMaximum(BigDecimal max) {
        this.adjuster.setMaximum(max);
        return this;
    }

    public FieldAdjusterDecimalHelper setMinimum(BigDecimal min) {
        this.adjuster.setMinimum(min);
        return this;
    }
    
}
