/*
 * Created on Aug 23, 2007
 *
 */
package tkt.foundation.form.meta.builder.adjuster;

import java.math.BigDecimal;
import java.util.Arrays;


public class FieldAdjusterCurrencyHelper extends AbstractFieldAdjusterHelper {

    public FieldAdjusterCurrencyHelper(FieldAdjuster adjuster) {
        super(adjuster);
    }

    public FieldAdjusterCurrencyHelper setMaximum(BigDecimal max) {
        this.adjuster.setCurrencyMaximum(max);
        return this;
    }

    public FieldAdjusterCurrencyHelper setMinimum(BigDecimal min) {
        this.adjuster.setCurrencyMinimum(min);
        return this;
    }
    
    public FieldAdjusterCurrencyHelper setAllowedCurrencyTypes(String... types) {
        this.adjuster.setAllowedCurrencyTypes(Arrays.asList(types));
        return this;
    }

}
