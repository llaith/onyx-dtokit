/*
 * Created on Aug 23, 2007
 *
 */
package tkt.foundation.form.meta.builder.adjuster;

import tkt.foundation.date.BusinessDate;


public class FieldAdjusterDateHelper extends AbstractFieldAdjusterHelper {

    public FieldAdjusterDateHelper(FieldAdjuster adjuster) {
        super(adjuster);
    }

    public FieldAdjusterDateHelper setMaximum(BusinessDate max) {
        this.adjuster.setMaximum(max);
        return this;
    }

    public FieldAdjusterDateHelper setMinimum(BusinessDate min) {
        this.adjuster.setMinimum(min);
        return this;
    }
    
}
