/*
 * Created on Apr 24, 2007
 *
 */
package tkt.foundation.form.meta.builder.xml;

public interface XmlConversionHandlerFactory {

    public XmlConversionHandler[] getConversionhandlers(); 
    
}
