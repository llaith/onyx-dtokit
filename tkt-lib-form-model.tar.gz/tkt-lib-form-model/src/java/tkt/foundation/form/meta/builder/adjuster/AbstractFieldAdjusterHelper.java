/*
 * Created on 08/06/2006
 *
 */
package tkt.foundation.form.meta.builder.adjuster;

import tkt.form.meta.FormMeta;

/**
 * 
 * @author nos
 *
 * Design Notes:
 *      a newForm() function isn't a good idea because you can have more newForms then getForms and loose some forms.
 *
 */
public abstract class AbstractFieldAdjusterHelper implements IFieldAdjuster {
    
    protected final FieldAdjuster adjuster;

    public AbstractFieldAdjusterHelper(FieldAdjuster adjuster) {
        this.adjuster = adjuster;
    }

    public IFieldAdjuster adjustBooleanField(String ident) {
        this.adjuster.adjustBooleanField(ident);
        return this.adjuster;
    }
    
    public IFieldAdjuster adjustCurrencyField(String ident) {
        this.adjuster.adjustCurrencyField(ident);
        return this.adjuster;
    }
    
    public IFieldAdjuster adjustDateFieldField(String ident) {
        this.adjuster.adjustDateFieldField(ident);
        return this.adjuster;
    }
    
    public IFieldAdjuster adjustDecimalField(String ident) {
        this.adjuster.adjustDecimalField(ident);
        return this.adjuster;
    }
    
    public IFieldAdjuster adjustIntegerField(String ident) {
        this.adjuster.adjustIntegerField(ident);
        return this.adjuster;
    }
    
    public IFieldAdjuster adjustLabelField(String ident) {
        this.adjuster.adjustLabelField(ident);
        return this.adjuster;
    }
    
    public IFieldAdjuster adjustMemoField(String ident) {
        this.adjuster.adjustMemoField(ident);
        return this.adjuster;
    }
    
    public IFieldAdjuster adjustRefField(String ident) {
        this.adjuster.adjustRefField(ident);
        return this.adjuster;
    }
    
    public IFieldAdjuster adjustSelectField(String ident) {
        this.adjuster.adjustSelectField(ident);
        return this.adjuster;
    }
    
    public IFieldAdjuster adjustSummaryField(String ident) {
        this.adjuster.adjustSummaryField(ident);
        return this.adjuster;
    }
    
    public IFieldAdjuster adjustTextField(String ident) {
        this.adjuster.adjustTextField(ident);
        return this.adjuster;
    }
    
    public IFieldAdjuster adjustTimeField(String ident) {
        this.adjuster.adjustTimeField(ident);
        return this.adjuster;
    }
    
    public AbstractFieldAdjusterHelper required() {
        this.adjuster.required();
        return this;
    }
    
    public FormMeta getForm() {
        return this.adjuster.getForm();
    }

}
