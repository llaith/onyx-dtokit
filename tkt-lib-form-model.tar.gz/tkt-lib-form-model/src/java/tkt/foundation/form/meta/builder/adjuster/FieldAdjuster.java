/*
 * Created on 08/06/2006
 *
 */
package tkt.foundation.form.meta.builder.adjuster;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import tkt.form.meta.CheckboxField;
import tkt.form.meta.DateField;
import tkt.form.meta.FieldMeta;
import tkt.form.meta.FormMeta;
import tkt.form.meta.LabelField;
import tkt.form.meta.MemoField;
import tkt.form.meta.BrowseField;
import tkt.form.meta.SelectField;
import tkt.form.meta.SummaryField;
import tkt.form.meta.TextField;
import tkt.foundation.date.BusinessDate;
import tkt.foundation.date.Time;
import tkt.foundation.form.meta.builder.FormBuilderException;
import tkt.foundation.form.meta.builder.field.CurrencyField;
import tkt.foundation.form.meta.builder.field.DecimalField;
import tkt.foundation.form.meta.builder.field.IntegerField;
import tkt.foundation.form.meta.builder.field.TimeField;

/**
 * 
 * @author nos
 *
 * Design Notes:
 *      *) a newForm() function isn't a good idea because you can have more newForms then getForms and loose some forms.
 *      *) implement some sort of finder so you can go : findBooleanFieldById("personType").setLabels("Person","Org");
 *
 */
public class FieldAdjuster implements IFieldAdjuster {
    
    private FormMeta formMeta = null;

    private FieldMeta lastField = null;
    private Map<String,FieldMeta> fieldIndex = new HashMap<String,FieldMeta>();
    
    private CheckboxField lastBooleanField = null;
    private CurrencyField lastCurrencyField = null;
    private BrowseField lastRefField = null;
    private DateField lastDateField = null;
    private TimeField lastTimeField = null;
    private DecimalField lastDecimalField = null;
    private IntegerField lastIntegerField = null;
    private LabelField lastLabelField = null;
    private SelectField lastSelectField = null;
    private SummaryField lastSummaryField = null;
    private MemoField lastMemoField = null;
    private TextField lastTextField = null;
    
    public FieldAdjuster(FormMeta formMeta) {
        this.formMeta = formMeta;
        this.scanForm(formMeta);
    }

    private void scanForm(FormMeta formMeta) {
        //
    }
    
    public FieldAdjuster required() {
        this.lastField.setRequired(true);
        return this;
    }
    
    public FormMeta getForm() {
        return this.formMeta;
    }

    private void clearFields() {
        this.lastBooleanField = null;
        this.lastRefField = null;
        this.lastDateField = null;
        this.lastTimeField = null;
        this.lastDecimalField = null;
        this.lastIntegerField = null;
        this.lastLabelField = null;
        this.lastSelectField = null;
        this.lastSummaryField = null;
        this.lastMemoField = null;
        this.lastTextField = null;
    }

    // For helpers to use
    protected FieldAdjuster setLabels(String trueLabel, String falseLabel) {
        if (this.lastBooleanField == null) throw new FormBuilderException("No current Boolean field");
        this.lastBooleanField.setLabels(trueLabel,falseLabel);
        return this;
    }

    protected FieldAdjuster setMask(String mask) {
        if (this.lastTextField != null) this.lastTextField.setMask(mask);
        else throw new FormBuilderException("This option requires a current TextField");
        return this;
    }

    protected FieldAdjuster setMaxLength(int max) {
        if (this.lastTextField != null) this.lastTextField.setMaxLength(max);
        else throw new FormBuilderException("This option requires a current TextField");
        return this;
    }
    
    protected FieldAdjuster setMinLength(int min) {
        if (this.lastTextField != null) this.lastTextField.setMinLength(min);
        else throw new FormBuilderException("This option requires a current TextField");
        return this;
    }
    
    protected FieldAdjuster setMinimum(Time min) {
        if (this.lastTimeField == null) throw new FormBuilderException("No current Time field");
        this.lastTimeField.setMin(min);
        return this;
    }
    
    protected FieldAdjuster setMinimum(BusinessDate min) {
        if (this.lastDateField == null) throw new FormBuilderException("No current BusinessDate field");
        this.lastDateField.setMin(min);
        return this;
    }
    
    protected FieldAdjuster setMinimum(BigDecimal min) {
        if (this.lastDecimalField == null) throw new FormBuilderException("No current Decimal field");
        this.lastDecimalField.setMinimum(min);
        return this;
    }
    
    protected FieldAdjuster setMinimum(BigInteger min) {
        if (this.lastIntegerField == null) throw new FormBuilderException("No current Integer field");
        this.lastIntegerField.setMinimum(min);
        return this;
    }
    
    protected FieldAdjuster setMaximum(Time max) {
        if (this.lastTimeField == null) throw new FormBuilderException("No current Time field");
        this.lastTimeField.setMax(max);
        return this;
    }
    
    protected FieldAdjuster setMaximum(BusinessDate max) {
        if (this.lastDateField == null) throw new FormBuilderException("No current BusinessDate field");
        this.lastDateField.setMax(max);
        return this;
    }
    
    protected FieldAdjuster setMaximum(BigDecimal max) {
        if (this.lastDecimalField == null) throw new FormBuilderException("No current Decimal field");
        this.lastDecimalField.setMaximum(max);
        return this;
    }
    
    protected FieldAdjuster setMaximum(BigInteger max) {
        if (this.lastIntegerField == null) throw new FormBuilderException("No current Integer field");
        this.lastIntegerField.setMaximum(max);
        return this;
    }

    protected FieldAdjuster setCurrencyMaximum(BigDecimal max) {
        if (this.lastCurrencyField == null) throw new FormBuilderException("No current Currency field");
        this.lastCurrencyField.setMaximum(max);
        return this;
    }
    
    protected FieldAdjuster setCurrencyMinimum(BigDecimal min) {
        if (this.lastCurrencyField == null) throw new FormBuilderException("No current Currency field");
        this.lastCurrencyField.setMinimum(min);
        return this;
    }

    public void setAllowedCurrencyTypes(List<String> types) {
        this.lastCurrencyField.setCurrencyCodeRestrictions(types);
    }

    public FieldAdjusterBooleanHelper adjustBooleanField(String ident) {
        this.clearFields();
        this.lastBooleanField = (CheckboxField) (this.lastField = this.fieldIndex.get(ident));
        return new FieldAdjusterBooleanHelper(this);
    }

    public FieldAdjusterCurrencyHelper adjustCurrencyField(String ident) {
        this.clearFields();
        this.lastCurrencyField = (CurrencyField) (this.lastField = this.fieldIndex.get(ident));
        return new FieldAdjusterCurrencyHelper(this);
    }

    public FieldAdjusterDateHelper adjustDateFieldField(String ident) {
        this.clearFields();
        this.lastDateField = (DateField) (this.lastField = this.fieldIndex.get(ident));
        return new FieldAdjusterDateHelper(this);
    }

    public FieldAdjusterDecimalHelper adjustDecimalField(String ident) {
        this.clearFields();
        this.lastDecimalField = (DecimalField) (this.lastField = this.fieldIndex.get(ident));
        return new FieldAdjusterDecimalHelper(this);
    }

    public FieldAdjusterIntegerHelper adjustIntegerField(String ident) {
        this.clearFields();
        this.lastIntegerField = (IntegerField) (this.lastField = this.fieldIndex.get(ident));
        return new FieldAdjusterIntegerHelper(this);
    }

    public FieldAdjuster adjustLabelField(String ident) {
        this.clearFields();
        this.lastLabelField = (LabelField) (this.lastField = this.fieldIndex.get(ident));
        return this;
    }

    public FieldAdjuster adjustMemoField(String ident) {
        this.clearFields();
        this.lastMemoField = (MemoField) (this.lastField = this.fieldIndex.get(ident));
        return this;
    }

    public FieldAdjuster adjustRefField(String ident) {
        this.clearFields();
        this.lastRefField = (BrowseField) (this.lastField = this.fieldIndex.get(ident));
        return this;
    }

    public FieldAdjuster adjustSelectField(String ident) {
        this.clearFields();
        this.lastSelectField = (SelectField) (this.lastField = this.fieldIndex.get(ident));
        return this;
    }

    public FieldAdjuster adjustSummaryField(String ident) {
        this.clearFields();
        this.lastSummaryField = (SummaryField) (this.lastField = this.fieldIndex.get(ident));
        return this;
    }

    public FieldAdjusterTextHelper adjustTextField(String ident) {
        this.clearFields();
        this.lastTextField = (TextField) (this.lastField = this.fieldIndex.get(ident));
        return new FieldAdjusterTextHelper(this);
    }

    public FieldAdjusterTimeHelper adjustTimeField(String ident) {
        this.clearFields();
        this.lastTimeField = (TimeField) (this.lastField = this.fieldIndex.get(ident));
        return new FieldAdjusterTimeHelper(this);
    }

}
