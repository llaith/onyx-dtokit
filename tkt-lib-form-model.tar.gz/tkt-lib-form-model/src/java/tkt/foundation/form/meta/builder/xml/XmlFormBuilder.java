/*
 * Created on Apr 16, 2007
 *
 */
package tkt.foundation.form.meta.builder.xml;

import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

import tkt.form.meta.AbstractFormSection;
import tkt.form.meta.CheckboxField;
import tkt.form.meta.DateField;
import tkt.form.meta.DialogSection;
import tkt.form.meta.FieldGroup;
import tkt.form.meta.FieldMeta;
import tkt.form.meta.FieldSection;
import tkt.form.meta.FormMeta;
import tkt.form.meta.LabelField;
import tkt.form.meta.MemoField;
import tkt.form.meta.BrowseField;
import tkt.form.meta.SelectField;
import tkt.form.meta.SummaryField;
import tkt.form.meta.TextField;
import tkt.foundation.form.meta.builder.field.CurrencyField;
import tkt.foundation.form.meta.builder.field.DecimalField;
import tkt.foundation.form.meta.builder.field.IntegerField;
import tkt.foundation.form.meta.builder.field.TimeField;
import tkt.foundation.ref.RefType;

public class XmlFormBuilder {

    private static DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");

    private Map<String,XmlConversionHandler> conversionHandlers = new HashMap<String,XmlConversionHandler>(); // string instead of class to avoid classloader issues
    
    
    public XmlFormBuilder(XmlConversionHandlerFactory factory) {
        for (XmlConversionHandler handler : factory.getConversionhandlers()) {
            this.registerConversionHandler(handler);
        }
    }
    
    public Document toXml(FormMeta formMeta) {

        Document document = DocumentHelper.createDocument();
        
        Element root = this.buildFormElement(document,formMeta);
        
        for (AbstractFormSection section : formMeta.getFormSections()) {
            
            if (section instanceof DialogSection) {
                this.buildDialogSection(root,(DialogSection)section);
            } else if (section instanceof FieldSection) {
                this.buildFormFieldSection(root,(FieldSection)section);
            } else {
                throw new RuntimeException("Unknown Type");
            }
            
        }
        
        
        return document;
    }
    
    private Element buildFormElement(Document document, FormMeta formMeta) {
        Element element = document.addElement("form");
        element.addAttribute("title",formMeta.getTitle());
        return element;
    }
    
    private void buildDialogSection(Element root, DialogSection section) {
        Element element = root.addElement("dialog-section");
        element.addAttribute("index",""+section.getPosition());
        element.addAttribute("heading",section.getHeading());
        element.addAttribute("description",section.getDescription());
    }
    
    private void buildFormFieldSection(Element root, FieldSection section) {
        Element element = root.addElement("field-section");
        // common tail attributes
        element.addAttribute("index",""+section.getPosition());
        element.addAttribute("title",section.getTitle());
        if (section.getHelpText() != null) element.addAttribute("helpText",section.getHelpText());
        boolean includeGrouping = (section.getGroups() == null) ? false : (section.getGroups().size() > 1);
        for (FieldGroup group : section.getGroups()) {
            this.buildFieldGroup(element,group,includeGrouping);
        }
    }

    private void buildFieldGroup(Element element, FieldGroup group, boolean includeGroups) {
        Element e = (includeGroups || group.getDependentField() != null) ? element.addElement("group") : element;
        if (group.getDependentField() != null) {
            e.addAttribute("depend-ident",group.getDependentField().getIdent());
            //String attr = (group.getDependentValue().getClass().getName().equals("java.lang.Boolean")) ? "depend-boolean" : "depend-string";    
            //e.addAttribute("depend-class",dependClass);
            e.addAttribute("depend-value",this.convertToString(group.getDependentValue()));
        }
        for (FieldMeta fieldMeta : group.getFields()) {
            this.buildField(e,fieldMeta);
        }
    }
    
    public void buildField(Element root, FieldMeta fieldMeta) {
        if (fieldMeta instanceof CheckboxField) this.buildBoolanFieldAttr(root.addElement("boolean"),(CheckboxField)fieldMeta);
        else if (fieldMeta instanceof CurrencyField) this.buildCurrencyFieldAttr(root.addElement("currency"),(CurrencyField)fieldMeta);
        else if (fieldMeta instanceof DateField) this.buildDateFieldAttr(root.addElement("date"),(DateField)fieldMeta);
        else if (fieldMeta instanceof DecimalField) this.buildDecimalFieldAttr(root.addElement("decimal"),(DecimalField)fieldMeta);
        else if (fieldMeta instanceof IntegerField) this.buildIntegerFieldAttr(root.addElement("integer"),(IntegerField)fieldMeta);
        else if (fieldMeta instanceof LabelField) this.buildLabelFieldAttr(root.addElement("label"),(LabelField)fieldMeta);
        else if (fieldMeta instanceof MemoField) this.buildMemoFieldAttr(root.addElement("memo"),(MemoField)fieldMeta);
        else if (fieldMeta instanceof BrowseField) this.buildRefFieldAttr(root.addElement("ref"),(BrowseField)fieldMeta);
        else if (fieldMeta instanceof SelectField) this.buildSelectFieldAttr(root.addElement("select"),(SelectField)fieldMeta);
        else if (fieldMeta instanceof SummaryField) this.buildSummaryFieldAttr(root.addElement("summary"),(SummaryField)fieldMeta);
        else if (fieldMeta instanceof TextField) this.buildTextFieldAttr(root.addElement("text"),(TextField)fieldMeta);
        else if (fieldMeta instanceof TimeField) this.buildTimeFieldAttr(root.addElement("time"),(TimeField)fieldMeta);
    }
    
    private Element buildFieldElementAttr(Element element, FieldMeta fieldMeta) {
        element.addAttribute("ident",fieldMeta.getIdent());
        if (fieldMeta.isRequired()) element.addAttribute("required",""+fieldMeta.isRequired());
        if (fieldMeta.isReadOnly()) element.addAttribute("readOnly",""+fieldMeta.isReadOnly());
        return element;
    }
    
    private void buildBoolanFieldAttr(Element element, CheckboxField field) {
        this.buildFieldElementAttr(element,field);
        if ( field.getTrueLabel() != null ) element.addAttribute("trueLabel",field.getTrueLabel());
        if ( field.getFalseLabel() != null ) element.addAttribute("falseLabel",field.getFalseLabel());
    }

    private void buildCurrencyFieldAttr(Element element, CurrencyField field) {
        this.buildFieldElementAttr(element,field);
        if ( field.getMinimum() != null ) element.addAttribute("min",field.getMinimum().toPlainString());
        if ( field.getMaximum() != null ) element.addAttribute("max",field.getMaximum().toPlainString());
        if ( ( field.getCurrencyCodeRestrictions() != null) && (!field.getCurrencyCodeRestrictions().isEmpty()) ) {
            StringBuffer buf = new StringBuffer();
            for (String code :field.getCurrencyCodeRestrictions()) {
                buf.append(code+",");
            }
            if (buf.length() > 0) buf.deleteCharAt(buf.length()-1);
            element.addAttribute("allowed-types",buf.toString());
        }
    }

    private void buildDateFieldAttr(Element element, DateField field) {
        this.buildFieldElementAttr(element,field);
        if ( field.getMinimum() != null ) element.addAttribute("min",dateFormatter.format(field.getMinimum().getDate()));
        if ( field.getMaximum() != null ) element.addAttribute("max",dateFormatter.format(field.getMaximum().getDate()));
    }

    private void buildDecimalFieldAttr(Element element, DecimalField field) {
        this.buildFieldElementAttr(element,field);
        if ( field.getMinimum() != null ) element.addAttribute("min",field.getMinimum().toPlainString());
        if ( field.getMaximum() != null ) element.addAttribute("max",field.getMaximum().toPlainString());
    }

    private void buildIntegerFieldAttr(Element element, IntegerField field) {
        this.buildFieldElementAttr(element,field);
        if ( field.getMinimum() != null ) element.addAttribute("min",field.getMinimum().toString());
        if ( field.getMaximum() != null ) element.addAttribute("max",field.getMaximum().toString());
    }

    private void buildLabelFieldAttr(Element element, LabelField field) {
        this.buildFieldElementAttr(element,field);
        if ( field.getText() != null ) element.addAttribute("text",field.getText());
    }

    private void buildMemoFieldAttr(Element element, MemoField field) {
        this.buildFieldElementAttr(element,field);
        if ( field.getMaxLength() > 0 ) element.addAttribute("max-length",""+field.getMaxLength());
    }

    private void buildRefFieldAttr(Element element, BrowseField field) {
        this.buildFieldElementAttr(element,field);
        element.addAttribute("allow-many",""+field.isAllowMany());
        if ( (field.getRefTypes() != null) && (!field.getRefTypes().isEmpty()) ) {
            StringBuffer buf = new StringBuffer();
            for (RefType rt : field.getRefTypes()) {
                buf.append(rt.getDisplayTypeName()+",");
            }
            if (buf.length() > 0) buf.deleteCharAt(buf.length()-1);
            element.addAttribute("ref-types",buf.toString());
        }
    }

    private void buildSelectFieldAttr(Element element, SelectField field) {
        this.buildFieldElementAttr(element,field);
        if ( (field.getChoices() != null) && (!field.getChoices().isEmpty()) ) {
            StringBuffer buf = new StringBuffer();
            for (String s : field.getChoices()) {
                buf.append(s+"|");
            }
            if (buf.length() > 0) buf.deleteCharAt(buf.length()-1);
            element.addAttribute("choices",buf.toString());
        }
    }

    private void buildSummaryFieldAttr(Element element, SummaryField field) {
        this.buildFieldElementAttr(element,field);
    }

    private void buildTextFieldAttr(Element element, TextField field) {
        this.buildFieldElementAttr(element,field);
        if (field.getMask() != null) element.addAttribute("mask",field.getMask());
        if (field.getMaxLength() > 0) element.addAttribute("max-length",""+field.getMaxLength());
        if (field.getMinLength() > 0) element.addAttribute("min-length",""+field.getMinLength());
    }
    
    private void buildTimeFieldAttr(Element element, TimeField field) {
        this.buildFieldElementAttr(element,field);
        if ( field.getMinimum() != null ) element.addAttribute("min",dateFormatter.format(field.getMinimum().getDate()));
        if ( field.getMaximum() != null ) element.addAttribute("max",dateFormatter.format(field.getMaximum().getDate()));
    }


    public void writeToFile(Document document, String filename) throws IOException {

        // lets write to a file
        XMLWriter writer = new XMLWriter(new FileWriter(filename));
        writer.write( document );
        writer.close();

    }

    public void writeToScreen(Document document) throws IOException {
        // Pretty print the document to System.out
        OutputFormat format = OutputFormat.createPrettyPrint();
        XMLWriter writer = new XMLWriter( System.out, format );
        writer.write( document );

    }    
    

    private void registerConversionHandler(XmlConversionHandler handler) {
        this.conversionHandlers.put(handler.getClassHandled().getName(),handler);
    }
    
    public String convertToString(Object o) {
        if (o instanceof String) return (String)o;
        
        XmlConversionHandler handler = this.conversionHandlers.get(o.getClass().getName());
        if (handler == null) throw new RuntimeException("Cannot find xml conversion handler for type of: "+o.getClass().getName());  
        
        return handler.toString(o);
    }
    
    public Object convertFromString(String s, String className) {
        if (String.class.getName().equals(className)) return s;
        
        XmlConversionHandler handler = this.conversionHandlers.get(className);
        if (handler == null) throw new RuntimeException("Cannot find xml conversion handler for type of: "+className);  
        
        return handler.fromString(s);
    }
    
}
