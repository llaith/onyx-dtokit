/*
 * Created on 08/06/2006
 *
 */
package tkt.foundation.form.meta.builder.adjuster;

import tkt.form.meta.FormMeta;

/**
 * 
 * @author nos
 *
 * Design Notes:
 *  Doesn't serve any purpose as an interface except to keep the Main formBuilder and it's helpers in sync.
 *
 */
public interface IFieldAdjuster {
    public IFieldAdjuster adjustBooleanField(String ident);
    public IFieldAdjuster adjustCurrencyField(String ident);
    public IFieldAdjuster adjustDateFieldField(String ident);
    public IFieldAdjuster adjustDecimalField(String ident);
    public IFieldAdjuster adjustIntegerField(String ident);
    public IFieldAdjuster adjustLabelField(String ident);
    public IFieldAdjuster adjustMemoField(String ident);
    public IFieldAdjuster adjustRefField(String ident);
    public IFieldAdjuster adjustSelectField(String ident);
    public IFieldAdjuster adjustSummaryField(String ident);
    public IFieldAdjuster adjustTextField(String ident);
    public IFieldAdjuster adjustTimeField(String ident);
    public IFieldAdjuster required();
    public FormMeta getForm();
}
