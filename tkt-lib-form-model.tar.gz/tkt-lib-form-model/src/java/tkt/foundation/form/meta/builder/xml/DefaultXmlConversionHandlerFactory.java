/*
 * Created on Apr 24, 2007
 *
 */
package tkt.foundation.form.meta.builder.xml;

import java.util.ArrayList;
import java.util.List;

public class DefaultXmlConversionHandlerFactory implements XmlConversionHandlerFactory {

    public XmlConversionHandler[] getConversionhandlers() {
        List<XmlConversionHandler> handlers = new ArrayList<XmlConversionHandler>();
        
        handlers.add(this.getBooleanHandler());
        
        return handlers.toArray(new XmlConversionHandler[0]);
    }

    private XmlConversionHandler getBooleanHandler() {
        return new XmlConversionHandler() {

            public Object fromString(String s) {
                return Boolean.valueOf(s);
            }

            public Class<?> getClassHandled() {
                return Boolean.class;
            }

            public String toString(Object o) {
                return ((Boolean)o).toString();
            }
        };
    }
    
    
}
