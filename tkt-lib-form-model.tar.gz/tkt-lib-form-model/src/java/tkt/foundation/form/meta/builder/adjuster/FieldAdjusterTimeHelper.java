/*
 * Created on Aug 23, 2007
 *
 */
package tkt.foundation.form.meta.builder.adjuster;

import tkt.foundation.date.Time;


public class FieldAdjusterTimeHelper extends AbstractFieldAdjusterHelper {

    public FieldAdjusterTimeHelper(FieldAdjuster adjuster) {
        super(adjuster);
    }

    public FieldAdjusterTimeHelper setMaximum(Time max) {
        this.adjuster.setMaximum(max);
        return this;
    }

    public FieldAdjusterTimeHelper setMinimum(Time min) {
        this.adjuster.setMinimum(min);
        return this;
    }
    
}
