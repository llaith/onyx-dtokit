/*
 * Created on Aug 22, 2007
 *
 */
package tkt.foundation.form.meta.builder;

public class FormBuilderException extends RuntimeException {

    public FormBuilderException(String message, Throwable cause) {
        super(message, cause);
    }

    public FormBuilderException(String message) {
        super(message);
    }

    public FormBuilderException(Throwable cause) {
        super(cause);
    }

}
