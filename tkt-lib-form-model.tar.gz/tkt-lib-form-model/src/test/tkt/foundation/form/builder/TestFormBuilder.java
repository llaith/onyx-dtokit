/*
 * Created on Jun 29, 2007
 *
 */
package tkt.foundation.form.builder;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

import tkt.form.meta.FieldGroup;
import tkt.form.meta.FieldMeta;
import tkt.form.meta.FieldSection;
import tkt.form.meta.FormMeta;
import tkt.foundation.form.meta.Heading;
import tkt.foundation.form.meta.SelectRefField;
import tkt.foundation.form.model.BooleanField;
import tkt.foundation.form.model.DateField;
import tkt.foundation.form.model.DecimalField;
import tkt.foundation.form.model.IntegerField;
import tkt.foundation.form.model.LabelField;
import tkt.foundation.form.model.MemoField;
import tkt.foundation.form.model.RefField;
import tkt.foundation.form.model.SelectField;
import tkt.foundation.form.model.SummaryField;
import tkt.foundation.form.model.TextField;
import tkt.foundation.ref.Ref;
import tkt.foundation.ref.RefType;
import tkt.foundation.ref.RefTypeQuery;

public class TestFormBuilder {

    public FormMeta getTestFormType1() {
        
        RefType rt1 = new RefType("Person",new String[] {"Firstname","Lastname"});
        RefType rt2 = new RefType("Business",new String[] {"Business Name","ABN"});
        RefTypeQuery rtq1 = new RefTypeQuery(rt1,"AllPersons");
        RefTypeQuery rtq2 = new RefTypeQuery(rt2,"AllBusinesses");
        Ref rp1 = new Ref(rt1,new String[] {"1"}, new String[] {"Nos","Doughty"});
        Ref rp2 = new Ref(rt1,new String[] {"2"}, new String[] {"Luke","Cunningham"});
        Ref ro1 = new Ref(rt2,new String[] {"3"}, new String[] {"Sera Software","C4358793"});
        Ref ro2 = new Ref(rt2,new String[] {"4"}, new String[] {"Icarusflop","B78392846"});
        
        FormMeta f = new FormMeta("Test Form");
        f.addFormSection(new Heading("A Form to Fill in"));

        CheckboxField bvf1 = new CheckboxField("Turn it on","On","Off");

        BrowseField crf = new BrowseField("Type",true,new RefTypeQuery[] {rtq1,rtq2});
        
        DateField dvf1= new DateField("Start Date", true,new Date(1,1,2000),new Date(1,1,2010));
        DateField dvf2 = new DateField("Start Date", false,new Date(1,1,2000),new Date(1,1,2010));
        
        DecimalField dcvf1 = new DecimalField("%",new BigDecimal(0.0),new BigDecimal(100.0));
        DecimalField dcvf2 = new DecimalField("Factor",new BigDecimal("-10.5"),new BigDecimal("10.5"));
        
        IntegerField ivf1 = new IntegerField("$",new BigInteger("10000"),new BigInteger("1000000"));
        IntegerField ivf2 = new IntegerField("Something",new BigInteger("10000"),new BigInteger("1000000"));
        
        LabelField lf1 = new LabelField("Label Field","Non editable label");
        
        SelectRefField srf1 = new SelectRefField("Manager",new Ref[] {rp1,rp2});
        
        SelectField stf1 = new SelectField("Role",new String[] {"Good Guy, Bad Guy"});
        
        SummaryField smrf1 = new SummaryField("Details");
        
        MemoField tavf1 = new MemoField("Comments",10);
        
        TextField tvf1 = new TextField("Code",3,10,"#");
        
        

        return f; 
    }
    
    private FieldSection getFieldSection(String title, String desc, FieldMeta<?>[] fields) {
        
        FieldSection section = new FieldSection(title,desc);
        FieldGroup group = new FieldGroup();
        section.addFieldGroup(group);
        for (FieldMeta<?> field : fields) {
            group.addFormField(field);
        }
        
        return section;
    }
    
    
}
