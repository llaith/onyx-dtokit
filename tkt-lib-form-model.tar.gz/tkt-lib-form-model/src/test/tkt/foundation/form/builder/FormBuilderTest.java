/*
 * Created on 07/06/2006
 *
 */
package tkt.foundation.form.builder;

import java.math.BigDecimal;
import java.math.BigInteger;

import junit.framework.TestCase;

import tkt.form.meta.FormMeta;
import tkt.foundation.date.BusinessDate;
import tkt.foundation.date.Time;
import tkt.foundation.form.meta.builder.humane.FormBuilder;
import tkt.foundation.form.meta.builder.xml.DefaultXmlConversionHandlerFactory;
import tkt.foundation.form.meta.builder.xml.XmlFormBuilder;
import tkt.foundation.ref.RefType;

/**
 * 
 * @author nos
 *
 *
 * Testing Strategy
 * 1) Create working equals for all form model elements
 * 2) Create FormBuilder and test against (via equals) a hand made form
 * 3) Create XMLFormBuilder and test against the same hand made form
 * 4)  Read Back into XMLFormBuilder then write out and test again
 *
 */
public class FormBuilderTest extends TestCase {
    
    class Role {
        Party party = new Party();
        float worth = 1.0f; 
    }
    
    class Party {
        String address = "32 Somewhere Street";
    }
    
    class Person extends Party {
        String fistName = "Nos";
        String lastName = "Doughty";
    }
    
    class Org extends Party {
        String name = "Something Pty Ltd";
    }
    
    RefType PERSON = new RefType("Person","Name");
    RefType ORG = new RefType("Organization","Name");
    
    
    public FormMeta getFormTwo() {
            int spos = 1; // could automate this - inside the builder - a good idea?
            int fpos = 1;
            return new FormBuilder("Person Details Form")
                                    .newDialogSection(spos++,"Personal Details","Please enter your details... blah")
                                    .newFieldSection(fpos++,"Party Type",null).newBooleanField("partyType").setLabels("Person","Org")
                                    .startFieldSection(fpos++,"Name",null).required()
                                        .startFieldGroup().depends("partyType",true)
                                            .newTextField("title").setMaxLength(12)
                                            .newTextField("firstname").required()
                                            .newTextField("lastname").setMaxLength(50).required()
                                        .endFieldGroup()
                                        .startFieldGroup().depends("partyType",false)
                                            .newTextField("abn").setMaxLength(12)
                                            .newTextField("name").required()
                                        .endFieldGroup()
                                    .endFieldSection()
                                    .newFieldSection(fpos++,"Spouse", null).newRefField("spouse", false)
                                    .newFieldSection(fpos++,"Birth Date",null).newDateField("birthdate")
                                    .newFieldSection(fpos++,"Comment",null).newTextField("comment").setMaxLength(50)
                                    .newDialogSection(fpos++,"Address Details",null)
                                    .newFieldSection(fpos++,"Comment",null).newSelectField("country","Australia","Singapore")
                                    .startFieldSection(fpos++,"Address",null).required()
                                        .startFieldGroup()
                                            .newTextField("address1")
                                            .newTextField("address2")
                                        .endFieldGroup()
                                        .newTextField("cityname").required()
                                    .endFieldSection()
                                    .getForm();
        
    }    
    
    public FormMeta getFormOne() {
        int pos = 1;
        return new FormBuilder("Person Details Form")
            .newFieldSection(pos++,"Boolean", null).newBooleanField("boolean").setLabels("true","false").required()
            .newFieldSection(pos++,"Currency", null).newCurrencyField("currency").setMinimum(new BigDecimal("0")).setAllowedCurrencyTypes("AUD","USD","GBP").required()
            .newFieldSection(pos++,"Date", null).newDateField("date").setMinimum(BusinessDate.Today()).setMaximum(BusinessDate.Today())
            .newFieldSection(pos++,"Decimal", null).newDecimalField("decimal").setMaximum(new BigDecimal("10.0")).setMinimum(new BigDecimal("1.0"))
            .newFieldSection(pos++,"Integer", null).newIntegerField("integer").setMaximum(new BigInteger("10")).setMinimum(new BigInteger("1"))
            .newFieldSection(pos++,"Label", null).newLabelField("label","Label Text")
            .newFieldSection(pos++,"Memo", null).newMemoField("memo")
            .newFieldSection(pos++,"Ref", null).newRefField("ref", false,this.PERSON)
            .newFieldSection(pos++,"Select", null).newSelectField("select","Choice1","Choice2")
            .newFieldSection(pos++,"Summary", null).newSummaryField("summary")
            .newFieldSection(pos++,"Text", null).newTextField("text")
            .newFieldSection(pos++,"Time", null).newTimeField("time").setMinimum(new Time()).setMaximum(new Time())
        .getForm();
        
    }
    
    public static void main(String[] args) {

        try {

            XmlFormBuilder builder = new XmlFormBuilder(new DefaultXmlConversionHandlerFactory());
            
            FormBuilderTest tst = new FormBuilderTest();
            
            FormMeta form1 = tst.getFormOne();
            FormMeta form2 = tst.getFormTwo();
            
            builder.writeToScreen(builder.toXml(form1));
            builder.writeToScreen(builder.toXml(form2));
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
    
    

    /*


    Formform = new XmlFormBuilder("
    
        <form title='something'>
            
    
    
    ").getForm();

     
     Include the ability to go: 
        Form form = new XmlFormBuilder("c:\forms.xml","PersonDetailsForm").getForm();
        
     And:
         new XmlFormBuilder().saveToXml("c:\forms.xml",form);
        
        
     */
    
    
}
